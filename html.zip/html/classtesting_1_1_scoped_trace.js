var classtesting_1_1_scoped_trace =
[
    [ "ScopedTrace", "classtesting_1_1_scoped_trace.html#a2da90b95d682d518cca472934d53c59c", null ],
    [ "ScopedTrace", "classtesting_1_1_scoped_trace.html#accd2a06cc941ffd7d6fe109adfdb4f19", null ],
    [ "ScopedTrace", "classtesting_1_1_scoped_trace.html#a1f453a2aade0db6955a111a7cb329615", null ],
    [ "~ScopedTrace", "classtesting_1_1_scoped_trace.html#aa8320ec2679f205cf2c14f508ba35b4d", null ]
];