var classtesting_1_1internal_1_1linked__ptr__internal =
[
    [ "depart", "classtesting_1_1internal_1_1linked__ptr__internal.html#a8699e539d9702d363ef0351012d1b3ca", null ],
    [ "join", "classtesting_1_1internal_1_1linked__ptr__internal.html#acd5a341459f7e81b10b4112d8c764e2a", null ],
    [ "join_new", "classtesting_1_1internal_1_1linked__ptr__internal.html#a742af1f65df2d5e2b7198a1b74264a83", null ]
];