var files_dup =
[
    [ "packages", "dir_93501a11e921083efbd154e0cdff5f10.html", "dir_93501a11e921083efbd154e0cdff5f10" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mylib.cpp", "mylib_8cpp.html", "mylib_8cpp" ],
    [ "mylib.h", "mylib_8h.html", "mylib_8h" ],
    [ "pch.cpp", "pch_8cpp.html", null ],
    [ "pch.h", "pch_8h.html", null ],
    [ "test.cpp", "test_8cpp.html", "test_8cpp" ]
];