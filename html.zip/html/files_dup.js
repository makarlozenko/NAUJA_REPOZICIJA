var files_dup =
[
    [ "mylib.cpp", "mylib_8cpp.html", "mylib_8cpp" ],
    [ "mylib.h", "mylib_8h.html", "mylib_8h" ],
    [ "Uzduotis2.cpp", "_uzduotis2_8cpp.html", "_uzduotis2_8cpp" ]
];