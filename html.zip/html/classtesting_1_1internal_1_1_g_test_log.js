var classtesting_1_1internal_1_1_g_test_log =
[
    [ "GTestLog", "classtesting_1_1internal_1_1_g_test_log.html#a364691bf972983a59cfa2891062a64af", null ],
    [ "~GTestLog", "classtesting_1_1internal_1_1_g_test_log.html#a978a099703bbaa0f380216e8d7ee03d3", null ],
    [ "GetStream", "classtesting_1_1internal_1_1_g_test_log.html#a74935e7a0b424c4a6312fb73dafab6b5", null ]
];