var globals_defs =
[
    [ "a", "globals_defs.html", null ],
    [ "e", "globals_defs_e.html", null ],
    [ "f", "globals_defs_f.html", null ],
    [ "g", "globals_defs_g.html", null ],
    [ "i", "globals_defs_i.html", null ],
    [ "s", "globals_defs_s.html", null ],
    [ "t", "globals_defs_t.html", null ]
];