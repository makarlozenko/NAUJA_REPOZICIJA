var class_zmogus =
[
    [ "Zmogus", "class_zmogus.html#a6ca61a3bcea221478551dd04419d2433", null ],
    [ "~Zmogus", "class_zmogus.html#ac5615bf607a8f2f1b303ffa04328d24d", null ],
    [ "getPav", "class_zmogus.html#a4e9511fb4e0854e8faf81dc5429094af", null ],
    [ "getVar", "class_zmogus.html#a01b808faac19355dd661d19fac17c027", null ],
    [ "setPav", "class_zmogus.html#ac38fadfa6b493c164a1aa8351eac7180", null ],
    [ "setVar", "class_zmogus.html#a5aab164ff22b475ef353bf2e922d571a", null ],
    [ "pav", "class_zmogus.html#ab80a99f04209e53782005784384cb9d7", null ],
    [ "var", "class_zmogus.html#ad15d365e72d0c3d71af7bd7e763d7e69", null ]
];