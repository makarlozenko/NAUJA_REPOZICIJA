var hierarchy =
[
    [ "Zmogus", "class_zmogus.html", [
      [ "Studentas", "class_studentas.html", null ]
    ] ]
];