var classtesting_1_1_test_case =
[
    [ "TestCase", "classtesting_1_1_test_case.html#a8a43b04703bfc7d56597fcb9b76ffbf5", null ],
    [ "~TestCase", "classtesting_1_1_test_case.html#ae8afec89feb954cc84317bd92c9b1bbe", null ],
    [ "ad_hoc_test_result", "classtesting_1_1_test_case.html#a9ee7cf7af1bb9359184f5bbc5f37ae38", null ],
    [ "disabled_test_count", "classtesting_1_1_test_case.html#a8ef690ab8ec74d02c99416637de71ae8", null ],
    [ "elapsed_time", "classtesting_1_1_test_case.html#acd7d6a77bce06da6ef90f5dad1c4def1", null ],
    [ "Failed", "classtesting_1_1_test_case.html#ae71c30eab6f1673b82090a0e745c2aa5", null ],
    [ "failed_test_count", "classtesting_1_1_test_case.html#a70e26eb070c75ae62a191fa610ea234f", null ],
    [ "GetTestInfo", "classtesting_1_1_test_case.html#a441e0eca232643671dc365c2924c255c", null ],
    [ "name", "classtesting_1_1_test_case.html#a74e30ab816e6bf8390150dbb9069a6c7", null ],
    [ "Passed", "classtesting_1_1_test_case.html#a29bbfd227b732a90198b5280c039c271", null ],
    [ "reportable_disabled_test_count", "classtesting_1_1_test_case.html#ad6b34335955967bc361b2fbacd2dd6c9", null ],
    [ "reportable_test_count", "classtesting_1_1_test_case.html#ae4e69f1a77b6aba274981e987e50acab", null ],
    [ "should_run", "classtesting_1_1_test_case.html#a843d6cd43f3e587bfa8681990b9d59df", null ],
    [ "successful_test_count", "classtesting_1_1_test_case.html#ab61929942a202f03903182866bd0e086", null ],
    [ "test_to_run_count", "classtesting_1_1_test_case.html#a57f115315eb756e23be6651bb5e6c638", null ],
    [ "total_test_count", "classtesting_1_1_test_case.html#aba3cab19aaf7295284f0832f2cf895a3", null ],
    [ "type_param", "classtesting_1_1_test_case.html#a0cf94f3e1c9f0bceb21a64511836ad0d", null ],
    [ "internal::UnitTestImpl", "classtesting_1_1_test_case.html#acc0a5e7573fd6ae7ad1878613bb86853", null ],
    [ "Test", "classtesting_1_1_test_case.html#a5b78b1c2e1fa07ffed92da365593eaa4", null ]
];