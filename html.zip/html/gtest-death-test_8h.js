var gtest_death_test_8h =
[
    [ "ASSERT_DEATH_IF_SUPPORTED", "gtest-death-test_8h.html#ab2f0f25b46353767179a49ebd15b7345", null ],
    [ "EXPECT_DEATH_IF_SUPPORTED", "gtest-death-test_8h.html#a8564de0e012dd0898949c513d1571f8b", null ],
    [ "GTEST_UNSUPPORTED_DEATH_TEST", "gtest-death-test_8h.html#aa5f42ab29859b7f49a901770d2e66855", null ],
    [ "GTEST_DECLARE_string_", "gtest-death-test_8h.html#a37b7e87f0a5f502c6918f37d1768c1f3", null ]
];