var classtesting_1_1internal_1_1_type_with_size_3_014_01_4 =
[
    [ "Int", "classtesting_1_1internal_1_1_type_with_size_3_014_01_4.html#a80351860c00ed665e73f952143f4484a", null ],
    [ "UInt", "classtesting_1_1internal_1_1_type_with_size_3_014_01_4.html#a7d559570f830bf35d095eeb94d98de58", null ]
];