var classtesting_1_1internal_1_1_floating_point =
[
    [ "Bits", "classtesting_1_1internal_1_1_floating_point.html#abf228bf6cd48f12c8b44c85b4971a731", null ],
    [ "FloatingPoint", "classtesting_1_1internal_1_1_floating_point.html#a0dabf840863e0df84046f171c891fe71", null ],
    [ "AlmostEquals", "classtesting_1_1internal_1_1_floating_point.html#a965214c1af2f9ac5adb1393794aa81e5", null ],
    [ "bits", "classtesting_1_1internal_1_1_floating_point.html#aed49c6dadf8dff4f65fbebef29bb1ae9", null ],
    [ "exponent_bits", "classtesting_1_1internal_1_1_floating_point.html#af6bf8fab8df572ecb137a3516ff390ae", null ],
    [ "fraction_bits", "classtesting_1_1internal_1_1_floating_point.html#aa17337e50a2ac855719bc0676529558f", null ],
    [ "is_nan", "classtesting_1_1internal_1_1_floating_point.html#a1fc654fd206efa98e480aa1e034f30d5", null ],
    [ "Max", "classtesting_1_1internal_1_1_floating_point.html#a145158f48d527cfc83150cc53bfd979f", null ],
    [ "Max", "classtesting_1_1internal_1_1_floating_point.html#a93b5901a99236ad6eded827f76bf3a44", null ],
    [ "sign_bit", "classtesting_1_1internal_1_1_floating_point.html#afb8a816bb598225d775caaf43a893ef0", null ]
];