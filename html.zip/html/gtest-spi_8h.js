var gtest_spi_8h =
[
    [ "EXPECT_FATAL_FAILURE", "gtest-spi_8h.html#a819a3fd7f8b8cf24b6f1b3a26708973d", null ],
    [ "EXPECT_FATAL_FAILURE_ON_ALL_THREADS", "gtest-spi_8h.html#ad8aac5bc859b2ddc07583636ae4f45cf", null ],
    [ "EXPECT_NONFATAL_FAILURE", "gtest-spi_8h.html#a8376fd6821bd88fd806697355e79e138", null ],
    [ "EXPECT_NONFATAL_FAILURE_ON_ALL_THREADS", "gtest-spi_8h.html#a9f4cf1f150fe9facfc4cbf0bae646ee9", null ],
    [ "GTEST_DISABLE_MSC_WARNINGS_PUSH_", "gtest-spi_8h.html#a88f79832f9d045112a76e9da8611cc13", null ]
];