var searchData=
[
  ['vidurkis_0',['vidurkis',['../class_studentas.html#aac9c20955bc3d77c943970318b7f86d3',1,'Studentas::vidurkis()'],['../mylib_8cpp.html#aa4263b488c6c8d15cb6544a2ba19670e',1,'vidurkis(vector&lt; int &gt; pazymiai):&#160;mylib.cpp'],['../mylib_8h.html#aa4263b488c6c8d15cb6544a2ba19670e',1,'vidurkis(vector&lt; int &gt; pazymiai):&#160;mylib.cpp']]]
];
