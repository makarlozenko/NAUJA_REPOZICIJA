var searchData=
[
  ['setegz_0',['setEgz',['../class_studentas.html#af7a2740c86cee79b07ea47b3eb819280',1,'Studentas']]],
  ['setkategorija_1',['setKategorija',['../class_studentas.html#a145c200e6e25196a8a5dd60372bbfb08',1,'Studentas']]],
  ['setpav_2',['setpav',['../class_zmogus.html#ac38fadfa6b493c164a1aa8351eac7180',1,'Zmogus::setPav()'],['../class_studentas.html#a0eee563d75a6e792f455b480fbd55e3c',1,'Studentas::setPav(const string &amp;p)']]],
  ['setpaz_3',['setPaz',['../class_studentas.html#ab47c484ada86b71e36e0b3f1874fe4f6',1,'Studentas']]],
  ['setrez_4',['setRez',['../class_studentas.html#a0ee99c873e9cb90f2af37943a74db904',1,'Studentas']]],
  ['setrezm_5',['setRezm',['../class_studentas.html#aa77a68eee0f7c2eb1f3be33aeab68a7a',1,'Studentas']]],
  ['setrezv_6',['setRezv',['../class_studentas.html#a03a99b5a6d7f932dfcfe9c25428856e3',1,'Studentas']]],
  ['setvar_7',['setvar',['../class_zmogus.html#a5aab164ff22b475ef353bf2e922d571a',1,'Zmogus::setVar()'],['../class_studentas.html#ae3b7a682b8081ce0b60de5ce4c9174d8',1,'Studentas::setVar(const string &amp;v)']]],
  ['skaiciuotigalutinibala_8',['skaiciuotigalutinibala',['../class_studentas.html#a78e4bc0896299c3054b8fdecfb16134b',1,'Studentas::skaiciuotiGalutiniBala()'],['../mylib_8cpp.html#acbd924f88643dc581512d95825507f02',1,'skaiciuotiGalutiniBala(Studentas studentas, bool naudotiMediana):&#160;mylib.cpp'],['../mylib_8h.html#acbd924f88643dc581512d95825507f02',1,'skaiciuotiGalutiniBala(Studentas studentas, bool naudotiMediana):&#160;mylib.cpp']]],
  ['spausdintiduomenis_9',['spausdintiduomenis',['../mylib_8cpp.html#a262489ff8ca17ecbc018c6315aadc71a',1,'spausdintiDuomenis(vector&lt; Studentas &gt; studentai):&#160;mylib.cpp'],['../mylib_8h.html#a262489ff8ca17ecbc018c6315aadc71a',1,'spausdintiDuomenis(vector&lt; Studentas &gt; studentai):&#160;mylib.cpp']]],
  ['studentas_10',['studentas',['../class_studentas.html',1,'Studentas'],['../class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539',1,'Studentas::Studentas()'],['../class_studentas.html#acb322244aac74a5397d0388a43dd4b31',1,'Studentas::Studentas(const string &amp;v, const string &amp;p, const string &amp;kat, const vector&lt; int &gt; &amp;pazymiai, int e)'],['../class_studentas.html#aef0484fe46cf05746f8ffc0d083fcf3e',1,'Studentas::Studentas(const Studentas &amp;other)']]]
];
