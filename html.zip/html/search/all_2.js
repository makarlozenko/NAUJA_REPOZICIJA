var searchData=
[
  ['getegz_0',['getEgz',['../class_studentas.html#a2f9dcb2fef2e6b3dbc1581779a90a68a',1,'Studentas']]],
  ['getkategorija_1',['getKategorija',['../class_studentas.html#a2e3a3ed60d6c7a8b39f46623c2a08c2e',1,'Studentas']]],
  ['getpav_2',['getpav',['../class_zmogus.html#a4e9511fb4e0854e8faf81dc5429094af',1,'Zmogus::getPav()'],['../class_studentas.html#a0dd3f768ea47de8abe75203cff2bc532',1,'Studentas::getPav() const']]],
  ['getpaz_3',['getPaz',['../class_studentas.html#ad3f38096e21f6463b8fe740a08f1fad3',1,'Studentas']]],
  ['getrandompaz_4',['getrandompaz',['../mylib_8cpp.html#a760f517d3b81e9be57d741ba22feb919',1,'GetRandomPaz(int minimum, int maximum):&#160;mylib.cpp'],['../mylib_8h.html#a760f517d3b81e9be57d741ba22feb919',1,'GetRandomPaz(int minimum, int maximum):&#160;mylib.cpp']]],
  ['getrez_5',['getRez',['../class_studentas.html#a0b5db276732ef0ce1151ac599bbb0661',1,'Studentas']]],
  ['getrezm_6',['getRezm',['../class_studentas.html#afb044e7db08ae77916f67475fe2cfef6',1,'Studentas']]],
  ['getrezv_7',['getRezv',['../class_studentas.html#a9b5efef3382d679fbdeb7aea3aefa23f',1,'Studentas']]],
  ['getvar_8',['getvar',['../class_zmogus.html#a01b808faac19355dd661d19fac17c027',1,'Zmogus::getVar()'],['../class_studentas.html#aca187ab9dc19de49a1eb32d4f8820e3e',1,'Studentas::getVar()']]]
];
